const fs = require('fs')
//~~~~~~~~~SETTING BOT~~~~~~~~~~//
global.owner = "6285183131924"
global.nama = "『𝐇𝐀𝐙𝐄𝐋𝐍𝐔𝐓』WA Bot v1.1 Gen1 "
global.namaowner = "hazelnut-offc"
global.namaBot = "『𝐇𝐀𝐙𝐄𝐋𝐍𝐔𝐓』WA Bot v1.1 Gen1 "
global.ch = 'https://whatsapp.com/channel/0029Vb601hd2v1IxmXcxK00u'
global.status = true
global.foother = "© 『𝐇𝐀𝐙𝐄𝐋𝐍𝐔𝐓』WA Bot v1.1 Gen1 "
global.namach = '『𝐇𝐀𝐙𝐄𝐋𝐍𝐔𝐓』WA Bot v1.1 Gen1 '
global.idch = '120363186130999681@newsletter'
global.namafile = '『𝐇𝐀𝐙𝐄𝐋𝐍𝐔𝐓』WA Bot v1.1 Gen1 '
global.yt = 'https://tiktok.com/@stc_ryzzz'
global.themeemoji = '🌸'
global.packname = "Sticker By"
global.author = "\n\n\n\n\nCreate By Hazelnut offc \nTIKTKK : stc_ryzzz"
global.creator = "6285183131924@s.whatsapp.net"
//~~~~~~~~~ Settings Payment ~~~~~~~~~//
global.dana = "085183131924"
global.ovo = "Tidak Tersedia"
global.qris = "-"
//====== [ THEME URL & URL ] ========//
global.thumb = fs.readFileSync('./kyami.jpg'); // Buffer Image
global.thumbnail = 'https://img1.pixhost.to/images/5477/594743370_biyuofficial.jpg'
global.Url = '-'
global.logodana = "-", 
global.logoovo = "-", 
//~~~~~~~~~ Settings panel ~~~~~~~~~//
global.domain = "-"
global.apikey = "-"
global.capikey = "-"
//~~~~~~~~~ Settings panel ~~~~~~~~~//
global.domain2 = "-"
global.apikey2 = "-"
global.capikey2 = "-"
//~~~~~~~~~ Settings panel ~~~~~~~~~//
global.domain3 = "-"
global.apikey3 = "-"
global.capikey3 = "-"
global.egg = "15"
global.loc = "1"
//~~~~~~~~~ Settings reply ~~~~~~~~~//
global.mess = {
    owner: "no, this is for owners only",
    group: "this is for groups only",
    private: "this is specifically for private chat"
}

global.packname = '『𝐇𝐀𝐙𝐄𝐋𝐍𝐔𝐓』WA Bot v1.1 Gen1 '
global.author = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n@Hazelnut-Offc'

global.pairing = "" //jangan di isi

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
